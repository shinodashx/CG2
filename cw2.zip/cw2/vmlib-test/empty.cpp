// You will need to define your own tests. Refer to CW1 or Exercise G.3 for
// examples.
